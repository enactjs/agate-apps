export default {
	weatherApiKey: 'c9de35da438a22a99da46bcf04a2b7af',
	mapApiKey: 'pk.eyJ1Ijoic3VnYXJkYXZlIiwiYSI6ImNqbmFsdjVnNTAwdHEzcm50N3VqOGRhdjQifQ.Hz6huSBROGXEwtMihTukvg'
};
